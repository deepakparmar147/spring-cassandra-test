package com.amdocs.cm.controller;


import com.amdocs.cm.model.Student;
import com.amdocs.cm.repository.StudentRepository;

import com.amdocs.cm.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/cm/")
@EnableAutoConfiguration
public class StudentController {
@Autowired
private StudentService studentService;

    @GetMapping
    public List<Student> getStudents(@PathVariable String roll){
        return studentService.getStudents();
    }

    @GetMapping("{id}")
    public Student getStudent(@PathVariable String id){
        return studentService.getStudent(id);
    }
    @PostMapping
    public String insert(@RequestBody List<Student> students){
//        List<Student> list=new ArrayList<Student>();
//        list.add(new Student("CA001","Deepak","Indore","75745745243","5th"));
        return studentService.addStudent(students);
    }
}
