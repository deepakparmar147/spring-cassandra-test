package com.amdocs.cm.repository;

import com.amdocs.cm.model.Student;
import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface StudentRepository extends CassandraRepository<Student, String> {
}
