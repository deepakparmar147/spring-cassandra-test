package com.amdocs.cm.service;

import com.amdocs.cm.model.Student;

import java.util.List;

public interface StudentService {

    public Student getStudent(String id);
    public List<Student> getStudents();
    public String addStudent(List<Student> student);
    public String removeStudent(String id);
    public String updateStudent(String id,Student student);
}
