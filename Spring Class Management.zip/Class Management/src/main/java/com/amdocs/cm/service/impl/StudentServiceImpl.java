package com.amdocs.cm.service.impl;

import com.amdocs.cm.model.Student;
import com.amdocs.cm.repository.StudentRepository;
import com.amdocs.cm.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import java.util.List;

@Service
public class StudentServiceImpl implements StudentService {

    @Autowired
    private StudentRepository repository;

    public Student getStudent(String id) {
        return repository.findById(id).orElse(null);
    }

    public List<Student> getStudents() {
        return repository.findAll();
    }

    public String addStudent(List<Student> students) {
        String message="Failed, try again";
        if (repository.saveAll(students)!=null){
            message="Added Successfully...";
        }
        return message;
    }

    public String removeStudent(String id) {
        String message="Deleted Successfully...";
        repository.deleteById(id);
        return message;
    }

    public String updateStudent(String id, Student student) {
        String message="Failed, try again";
        if (repository.existsById(id)){
            repository.deleteById(id);
            repository.save(student);
            message="Updated Successfully";
        }else {
            message="Student not exist...";
        }

        return message;
    }
}
